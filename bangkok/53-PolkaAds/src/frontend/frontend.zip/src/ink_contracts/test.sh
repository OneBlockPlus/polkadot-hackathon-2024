cargo fmt

cargo test -- --nocapture