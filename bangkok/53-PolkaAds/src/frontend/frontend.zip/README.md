# Start Backend

1. cd ./backend
2. node server.js

# Start Frontend

1. cd ./frontend
2. npm start

# Run web app

http://localhost:3000/
